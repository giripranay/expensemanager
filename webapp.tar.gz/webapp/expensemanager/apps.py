from django.apps import AppConfig


class ExpensemanagerConfig(AppConfig):
    name = 'expensemanager'
